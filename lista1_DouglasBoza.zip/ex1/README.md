
    Executar testes:
   
    g++ -Wall -std=c++11 test/main.cpp src/int_ranges.cpp -I include -L lib -lgtest -lgtest_main -pthread -o run_tests

    Arquivos com código em:
        src/driver.cpp 
        src/int_ranges.cpp
        include/int_ranges.h 
    

